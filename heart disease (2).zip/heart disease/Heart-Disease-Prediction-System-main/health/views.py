import logging
import os
import pickle
import sys

import joblib
import matplotlib
import train
from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
import datetime

from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, mean_squared_error

from .forms import DoctorForm
from .models import *
from django.contrib.auth import authenticate, login, logout
import numpy as np
import pandas as pd

import matplotlib.pyplot as plt
import seaborn as sns
sns.set_style('darkgrid')

from sklearn.preprocessing import StandardScaler, MinMaxScaler, RobustScaler
from sklearn.model_selection import train_test_split, GridSearchCV
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay

import seaborn as sns
import plotly.express as px
import pandas as pd
import io
import base64

from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from django.http import HttpResponse
# Create your views here.

ml_path = os.path.join(os.path.dirname(__file__), '..', 'models')
sys.path.append(ml_path)
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(project_root)

# Debug: Print sys.path to verify
print("sys.path:", sys.path)
# Debug: Check if ml/utils.py exists
utils_path = os.path.join(project_root, "ml", "utils.py")
print("Does utils.py exist?", os.path.exists(utils_path))





def Home(request):
    return render(request,'carousel.html')

def Admin_Home(request):
    dis = Search_Data.objects.all()
    pat = Patient.objects.all()
    doc = Doctor.objects.all()
    feed = Feedback.objects.all()

    d = {'dis':dis.count(),'pat':pat.count(),'doc':doc.count(),'feed':feed.count()}
    return render(request,'admin_home.html',d)

@login_required(login_url="login")
def assign_status(request,pid):
    doctor = Doctor.objects.get(id=pid)
    if doctor.status == 1:
        doctor.status = 2
        messages.success(request, 'Selected doctor are successfully withdraw his approval.')
    else:
        doctor.status = 1
        messages.success(request, 'Selected doctor are successfully approved.')
    doctor.save()
    return redirect('view_doctor')

@login_required(login_url="login")
def User_Home(request):
    return render(request,'patient_home.html')

@login_required(login_url="login")
def Doctor_Home(request):
    return render(request,'doctor_home.html')

def About(request):
    return render(request,'about.html')

def Contact(request):
    return render(request,'contact.html')


def Gallery(request):
    return render(request,'gallery.html')


def Login_User(request):
    error = ""
    if request.method == "POST":
        u = request.POST['uname']
        p = request.POST['pwd']
        user = authenticate(username=u, password=p)
        sign = ""
        if user:
            try:
                sign = Patient.objects.get(user=user)
            except:
                pass
            if sign:
                login(request, user)
                error = "pat1"
            else:
                pure=False
                try:
                    pure = Doctor.objects.get(status=1,user=user)
                except:
                    pass
                if pure:
                    login(request, user)
                    error = "pat2"
                else:
                    login(request, user)
                    error="notmember"
        else:
            error="not"
    d = {'error': error}
    return render(request, 'login.html', d)

def Login_admin(request):
    error = ""
    if request.method == "POST":
        u = request.POST['uname']
        p = request.POST['pwd']
        user = authenticate(username=u, password=p)
        if user.is_staff:
            login(request, user)
            error="pat"
        else:
            error="not"
    d = {'error': error}
    return render(request, 'admin_login.html', d)

def Signup_User(request):
    error = ""
    if request.method == 'POST':
        f = request.POST['fname']
        l = request.POST['lname']
        u = request.POST['uname']
        e = request.POST['email']
        p = request.POST['pwd']
        d = request.POST['dob']
        con = request.POST['contact']
        add = request.POST['add']
        type = request.POST['type']
        im = request.FILES['image']
        dat = datetime.date.today()
        user = User.objects.create_user(email=e, username=u, password=p, first_name=f,last_name=l)
        if type == "Patient":
            Patient.objects.create(user=user,contact=con,address=add,image=im,dob=d)
        else:
            Doctor.objects.create(dob=d,image=im,user=user,contact=con,address=add,status=2)
        error = "create"
    d = {'error':error}
    return render(request,'register.html',d)

def Logout(request):
    logout(request)
    return redirect('home')

@login_required(login_url="login")
def Change_Password(request):
    sign = 0
    user = User.objects.get(username=request.user.username)
    error = ""
    if not request.user.is_staff:
        try:
            sign = Patient.objects.get(user=user)
            if sign:
                error = "pat"
        except:
            sign = Doctor.objects.get(user=user)
    terror = ""
    if request.method=="POST":
        n = request.POST['pwd1']
        c = request.POST['pwd2']
        o = request.POST['pwd3']
        if c == n:
            u = User.objects.get(username__exact=request.user.username)
            u.set_password(n)
            u.save()
            terror = "yes"
        else:
            terror = "not"
    d = {'error':error,'terror':terror,'data':sign}
    return render(request,'change_password.html',d)


def preprocess_inputs(df, scaler):

    # Define constants
    LOG_DIR = "models"
    LOG_FILE = os.path.join(LOG_DIR, "models/preprocessing.log")
    DATA_FILE = "Machine_Learning/heart.csv"  # Change this path if needed
    PROCESSED_FILE = "models/preprocessed.csv"  # File to save preprocessed data

    FEATURES = ['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg',
                'thalach', 'exang', 'oldpeak', 'slope', 'ca', 'thal', 'target']  # Includes 'target'

    # Ensure log directory exists
    os.makedirs(LOG_DIR, exist_ok=True)

    # Configure logging
    logging.basicConfig(
        filename=LOG_FILE,
        level=logging.DEBUG,
        format="%(asctime)s - %(levelname)s - %(message)s",
    )

    logging.info("✅ Logging initialized successfully!")

    def load_data(filepath=DATA_FILE):
        """
        Load dataset from CSV and return features (X) and target (y).
        Logs errors if data loading fails.
        """
        try:
            logging.info(f"📥 Loading data from {filepath}...")

            if not os.path.exists(filepath):
                logging.error(f"❌ File not found: {filepath}")
                return None, None  # Return None if the file is missing

            df = pd.read_csv(filepath)

            # Ensure dataset has all required features
            missing_cols = [col for col in FEATURES if col not in df.columns]
            if missing_cols:
                logging.error(f"❌ Missing columns in dataset: {missing_cols}")
                return None, None

            logging.info(f"✅ Data Loaded Successfully. Shape: {df.shape}")

            X = df.drop(columns=["target"])  # Features
            y = df["target"]  # Labels

            return X, y
        except pd.errors.EmptyDataError:
            logging.error("❌ Error: The dataset is empty.")
            return None, None
        except Exception as e:
            logging.error(f"❌ Unexpected error while loading data: {e}")
            return None, None

    def save_preprocessed_data(X, y, filepath=PROCESSED_FILE):
        """
        Saves the preprocessed data to a CSV file.
        """
        try:
            if X is None or y is None:
                logging.error("❌ No data to save. Preprocessing failed.")
                return False

            # Merge X and y into a single DataFrame
            df = pd.concat([X, y], axis=1)
            df.to_csv(filepath, index=False)

            logging.info(f"✅ Preprocessed data saved to {filepath}")
            return True
        except Exception as e:
            logging.error(f"❌ Error saving preprocessed data: {e}")
            return False

    def preprocess_input(data_dict):
        """
        Convert user input dictionary into a numerical NumPy array for model prediction.
        Logs any conversion errors.
        """
        try:
            list_data = []
            for key in FEATURES[:-1]:  # Exclude "target"
                value = data_dict.get(key, 0)  # Default to 0 if missing
                if key == "sex":
                    list_data.append(0 if str(value).lower() in ["male", "m"] else 1)
                else:
                    list_data.append(float(value))

            logging.info(f"✅ Preprocessed input: {list_data}")
            return np.array(list_data).reshape(1, -1)

        except ValueError as ve:
            logging.error(f"❌ ValueError in input preprocessing: {ve}")
            return None
        except Exception as e:
            logging.error(f"❌ Unexpected error in input preprocessing: {e}")
            return None

    if __name__ == "__main__":
        # Load and preprocess data
        X, y = load_data()

        if X is not None and y is not None:
            logging.info("🚀 Data successfully loaded and ready for preprocessing!")
            print("🚀 Data successfully loaded and ready for preprocessing!")

            # Save preprocessed data
            if save_preprocessed_data(X, y):
                print(f"✅ Preprocessed data saved to {PROCESSED_FILE}")
            else:
                print("❌ Failed to save preprocessed data.")
        else:
            logging.error("❌ Data loading failed! Check logs for more details.")
            print("❌ Data loading failed! Check logs for more details.")


def prdict_heart_disease(list_data):
    csv_file = Admin_Helath_CSV.objects.get(id=1)
    df = pd.read_csv(csv_file.csv_file)

    LOG_DIR = "models"
    MODEL_DIR = "ml/models/models"

    # Ensure directories exist
    os.makedirs(LOG_DIR, exist_ok=True)
    os.makedirs(MODEL_DIR, exist_ok=True)

    LOG_FILE = os.path.join(LOG_DIR, "training.log")

    # Configure logging
    logging.basicConfig(
        filename=LOG_FILE,
        level=logging.DEBUG,
        format="%(asctime)s - %(levelname)s - %(message)s",
    )

    DATA_FILE = "ml/models/preprocessed.csv"

    def load_data():
        """Load preprocessed data for training."""
        try:
            if not os.path.exists(DATA_FILE):
                logging.error("❌ Processed data file not found!")
                raise FileNotFoundError("Processed data file missing!")

            df = pd.read_csv(DATA_FILE)
            logging.info("✅ Data loaded successfully.")
            return df
        except Exception as e:
            logging.error(f"❌ Error loading data: {str(e)}")
            raise

def train():
    """Train multiple models with hyperparameter tuning and save the best, or load existing models."""
    try:
        # Paths for data and models
        DATA_FILE = os.path.join(settings.BASE_DIR, 'ml', 'models', 'preprocessed.csv')
        MODEL_DIR = os.path.join(settings.BASE_DIR, 'ml', 'models', 'models')
        STATIC_CONFUSION_MATRIX_DIR = os.path.join(settings.BASE_DIR, 'static', 'confusion_matrices')

        # Ensure required directories exist
        os.makedirs(MODEL_DIR, exist_ok=True)
        os.makedirs(STATIC_CONFUSION_MATRIX_DIR, exist_ok=True)

        # Check if the dataset exists
        if not os.path.exists(DATA_FILE):
            raise FileNotFoundError(f"The file {DATA_FILE} does not exist.")

        print("Data File Path:", DATA_FILE)

        # Load and prepare data
        df = pd.read_csv(DATA_FILE)
        feature_names = ['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg',
                         'thalach', 'exang', 'oldpeak', 'slope', 'ca', 'thal']
        target = 'target'

        if target not in df.columns:
            raise KeyError("Target column 'target' not found in dataset!")

        X = df[feature_names]
        y = df[target]

        # Split data into training and testing sets
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

        # Scale features
        scaler_path = os.path.join(MODEL_DIR, "scaler.pkl")
        if os.path.exists(scaler_path):
            scaler = joblib.load(scaler_path)  # Load existing scaler
        else:
            scaler = StandardScaler()  # Create and save scaler
            X_train = scaler.fit_transform(X_train)
            joblib.dump(scaler, scaler_path)

        X_test = scaler.transform(X_test)

        # Define models and hyperparameters
        models = {
            'RandomForest': RandomForestClassifier(random_state=42),
            'GradientBoosting': GradientBoostingClassifier(random_state=42),
            'SVM': SVC(probability=True, random_state=42)
        }

        param_grids = {
            'RandomForest': {'n_estimators': [100, 200, 500], 'max_depth': [None, 10, 20], 'min_samples_split': [2, 5, 10]},
            'GradientBoosting': {'n_estimators': [100, 200], 'learning_rate': [0.01, 0.1], 'max_depth': [3, 5]},
            'SVM': {'C': [0.1, 1, 10], 'kernel': ['linear', 'rbf']}
        }

        best_models = {}
        evaluation_results = {}

        # Train or load models
        for model_name, model in models.items():
            model_path = os.path.join(MODEL_DIR, f"{model_name}.pkl")
            if os.path.exists(model_path):
                best_models[model_name] = joblib.load(model_path)  # Load existing model
            else:
                # Train model with hyperparameter tuning
                grid_search = GridSearchCV(model, param_grids[model_name], cv=5, scoring='accuracy')
                grid_search.fit(X_train, y_train)

                best_models[model_name] = grid_search.best_estimator_
                joblib.dump(best_models[model_name], model_path)  # Save the trained model
                print("Best parameters:", grid_search.best_params_)
            # Evaluate the model
            y_pred = best_models[model_name].predict(X_test)
            accuracy = accuracy_score(y_test, y_pred)
            precision = precision_score(y_test, y_pred, average='weighted')
            recall = recall_score(y_test, y_pred, average='weighted')
            f1 = f1_score(y_test, y_pred, average='weighted')
            mse = mean_squared_error(y_test, y_pred)

            # Generate and save confusion matrix
            cm = confusion_matrix(y_test, y_pred)
            cm_image_path = os.path.join(STATIC_CONFUSION_MATRIX_DIR, f"{model_name}_confusion_matrix.png")
            relative_cm_path = f"confusion_matrices/{model_name}_confusion_matrix.png"
            plot_confusion_matrix(cm, model_name, cm_image_path)

            # Store evaluation results
            evaluation_results[model_name] = {
                'accuracy': accuracy,
                'precision': precision,
                'recall': recall,
                'f1': f1,
                'mse': mse,
                'confusion_matrix_path': relative_cm_path,
                'hyperparameters': getattr(best_models[model_name], 'get_params', lambda: {})(),
            }

        # Select the best model based on accuracy
        best_model_name = max(evaluation_results, key=lambda k: evaluation_results[k]['accuracy'])
        best_model_metrics = evaluation_results[best_model_name]

        print(f"\n🏆 Best model: {best_model_name} with Accuracy: {best_model_metrics['accuracy']:.4f}")
        return best_models, evaluation_results, best_model_name

    except Exception as e:
        logging.error(f"❌ Training error: {str(e)}", exc_info=True)
        print(f"Error: {str(e)}")
        return {}, {}, "N/A"  # Return default values in case of an error

def plot_confusion_matrix(cm, model_name, output_path):
    """Plot and save the confusion matrix."""
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=['No Disease', 'Disease'],
                yticklabels=['No Disease', 'Disease'])
    plt.title(f'Confusion Matrix - {model_name}')
    plt.xlabel('Predicted')
    plt.ylabel('Actual')
    plt.savefig(output_path)  # Save the plot
    plt.close()  # Close the plot to

@login_required(login_url="login")
def add_doctor(request,pid=None):
    doctor = None
    if pid:
        doctor = Doctor.objects.get(id=pid)
    if request.method == "POST":
        form = DoctorForm(request.POST, request.FILES, instance = doctor)
        if form.is_valid():
            new_doc = form.save()
            new_doc.status = 1
            if not pid:
                user = User.objects.create_user(password=request.POST['password'], username=request.POST['username'], first_name=request.POST['first_name'], last_name=request.POST['last_name'])
                new_doc.user = user
            new_doc.save()
            return redirect('view_doctor')
    d = {"doctor": doctor}
    return render(request, 'add_doctor.html', d)

@login_required(login_url="login")
def add_heartdetail(request):
    if request.method == "POST":
        # Initialize an empty list to store form data
        list_data = []

        # Extract form data from the POST request
        value_dict = request.POST
        count = 0

        for key, value in value_dict.items():
            if count == 0:
                count = 1
                continue
            if key == "sex" and value[0].lower() in ["male", "m"]:
                list_data.append(0)
                continue
            elif key == "sex":
                list_data.append(1)
                continue

        # Redirect to the prediction result page
        return predict_desease(request, list_data)

    # Render the form template for GET requests
    return render(request, 'add_heartdetail.html')
def generate_bar_chart(prediction_probs):
    """Generate a bar chart for prediction probabilities."""
    plt.figure(figsize=(8, 4))
    plt.bar(prediction_probs.keys(), prediction_probs.values(), color=['green', 'red'])
    plt.title('Prediction Probabilities')
    plt.ylabel('Probability')
    plt.ylim(0, 1)
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_png = buffer.getvalue()
    buffer.close()
    return base64.b64encode(image_png).decode('utf-8')

def generate_pie_chart(prediction_dist):
    """Generate a pie chart for prediction distribution."""
    plt.figure(figsize=(6, 6))
    plt.pie(prediction_dist.values(), labels=prediction_dist.keys(), autopct='%1.1f%%', colors=['green', 'red'])
    plt.title('Prediction Distribution')
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_png = buffer.getvalue()
    buffer.close()
    return base64.b64encode(image_png).decode('utf-8')

def generate_histogram(data, feature_name):
    """Generate a histogram for a specific feature."""
    plt.figure(figsize=(8, 4))
    plt.hist(data, bins=5, color='blue', edgecolor='black')
    plt.title(f'{feature_name} Distribution')
    plt.xlabel(feature_name)
    plt.ylabel('Frequency')
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_png = buffer.getvalue()
    buffer.close()
    return base64.b64encode(image_png).decode('utf-8')

def generate_heatmap(df):
    """Generate a heatmap for feature correlations."""
    plt.figure(figsize=(10, 6))
    sns.heatmap(df.corr(), annot=True, cmap='coolwarm')
    plt.title('Feature Correlation Heatmap')
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_png = buffer.getvalue()
    buffer.close()
    return base64.b64encode(image_png).decode('utf-8')

def generate_interactive_plot(df, x, y, title):
    """Generate an interactive Plotly chart."""
    print(f"DataFrame Columns: {df.columns}")  # Debug: Check columns
    print(f"DataFrame Head:\n{df.head()}")
    fig = px.bar(df, x=x, y=y, title=title)
    # Simplify the JSON output
    simplified_fig = {
        "data": [{
            "x": df[x].tolist(),
            "y": df[y].tolist(),
            "type": "bar",
            "name": ""
        }],
        "layout": {
            "title": {"text": title},
            "xaxis": {"title": {"text": x}},
            "yaxis": {"title": {"text": y}},
        }
    }
    return simplified_fig
    graph_json = fig.to_json()
    print(f"Plotly JSON: {graph_json}")
    return graph_json

def predict_desease(request, list_data):
    # Example prediction data
    pred = [0]  # Replace with actual prediction logic
    accuracy = 0.95  # Replace with actual accuracy

    # Fetch patient and doctor data
    patient = Patient.objects.get(user=request.user)
    doctor = Doctor.objects.filter(address__icontains=patient.address)

    # Example data for visualizations
    prediction_probs = {'No Disease': 0.3, 'Disease': 0.7}
    prediction_dist = {'No Disease': 30, 'Disease': 70}
    ages = [25, 30, 35, 40, 45, 50, 55, 60, 65, 70]
    df = pd.DataFrame({
        'age': [25, 30, 35, 40, 45, 50, 55, 60, 65, 70],
        'chol': [200, 220, 240, 260, 280, 300, 320, 340, 360, 380],
        'thalach': [150, 160, 170, 180, 190, 200, 210, 220, 230, 240],
    })

    # Generate visualizations
    bar_chart = generate_bar_chart(prediction_probs)
    pie_chart = generate_pie_chart(prediction_dist)
    histogram = generate_histogram(ages, 'Age')
    heatmap = generate_heatmap(df)
    interactive_plot = generate_interactive_plot(df, x='age', y='chol', title='Age vs Cholesterol')

    # Prepare context data
    context = {
        'pred': pred[0],
        'accuracy': accuracy,
        'doctor': doctor,
        'status': "You are at high risk of heart disease. This is what you can do" if pred[0] == 0 else "You at low risk of heart disease:",
        'recommendations': [
            "Follow a heart-healthy diet rich in fruits, vegetables, and whole grains.",
            "Exercise regularly (at least 30 minutes a day, 5 days a week).",
            "Take prescribed medications as directed by your doctor.",
            "Quit smoking and avoid secondhand smoke.",
            "Manage stress through meditation, yoga, or deep breathing exercises.",
            "Monitor your blood pressure, cholesterol, and blood sugar levels regularly.",
            "Limit alcohol consumption.",
            "Get at least 7-9 hours of quality sleep each night.",
        ] if pred[0] == 0 else [
            "Maintain a balanced diet with plenty of fruits, vegetables, and lean proteins.",
            "Stay physically active with regular exercise.",
            "Avoid smoking and limit alcohol consumption.",
            "Monitor your weight and maintain a healthy BMI.",
            "Get regular health checkups to monitor your heart health.",
            "Manage stress through relaxation techniques.",
            "Stay hydrated and limit processed foods.",
        ],
        'bar_chart': bar_chart,
        'pie_chart': pie_chart,
        'histogram': histogram,
        'heatmap': heatmap,
        'interactive_plot': interactive_plot,
    }
    return render(request, 'predict_disease.html', context)


@login_required(login_url="login")
def view_search_pat(request):
    doc = None
    try:
        doc = Doctor.objects.get(user=request.user)
        data = Search_Data.objects.filter(patient__address__icontains=doc.address).order_by('-id')
    except:
        try:
            doc = Patient.objects.get(user=request.user)
            data = Search_Data.objects.filter(patient=doc).order_by('-id')
        except:
            data = Search_Data.objects.all().order_by('-id')
    return render(request,'view_search_pat.html',{'data':data})

@login_required(login_url="login")
def delete_doctor(request,pid):
    doc = Doctor.objects.get(id=pid)
    doc.delete()
    return redirect('view_doctor')

@login_required(login_url="login")
def delete_feedback(request,pid):
    doc = Feedback.objects.get(id=pid)
    doc.delete()
    return redirect('view_feedback')

@login_required(login_url="login")
def delete_patient(request,pid):
    doc = Patient.objects.get(id=pid)
    doc.delete()
    return redirect('view_patient')

@login_required(login_url="login")
def delete_searched(request,pid):
    doc = Search_Data.objects.get(id=pid)
    doc.delete()
    return redirect('view_search_pat')

@login_required(login_url="login")
def View_Doctor(request):
    doc = Doctor.objects.all()
    d = {'doc':doc}
    return render(request,'view_doctor.html',d)

@login_required(login_url="login")
def View_Patient(request):
    patient = Patient.objects.all()
    d = {'patient':patient}
    return render(request,'view_patient.html',d)

@login_required(login_url="login")
def View_Feedback(request):
    dis = Feedback.objects.all()
    d = {'dis':dis}
    return render(request,'view_feedback.html',d)

@login_required(login_url="login")
def View_My_Detail(request):
    terror = ""
    user = User.objects.get(id=request.user.id)
    error = ""
    try:
        sign = Patient.objects.get(user=user)
        error = "pat"
    except:
        sign = Doctor.objects.get(user=user)
    d = {'error': error,'pro':sign}
    return render(request,'profile_doctor.html',d)

@login_required(login_url="login")
def Edit_Doctor(request,pid):
    doc = Doctor.objects.get(id=pid)
    error = ""
    # type = Type.objects.all()
    if request.method == 'POST':
        f = request.POST['fname']
        l = request.POST['lname']
        e = request.POST['email']
        con = request.POST['contact']
        add = request.POST['add']
        cat = request.POST['type']
        try:
            im = request.FILES['image']
            doc.image=im
            doc.save()
        except:
            pass
        dat = datetime.date.today()
        doc.user.first_name = f
        doc.user.last_name = l
        doc.user.email = e
        doc.contact = con
        doc.category = cat
        doc.address = add
        doc.user.save()
        doc.save()
        error = "create"
    d = {'error':error,'doc':doc,'type':type}
    return render(request,'edit_doctor.html',d)

@login_required(login_url="login")
def Edit_My_deatail(request):
    terror = ""
    print("Hii welvome")
    user = User.objects.get(id=request.user.id)
    error = ""
    # type = Type.objects.all()
    try:
        sign = Patient.objects.get(user=user)
        error = "pat"
    except:
        sign = Doctor.objects.get(user=user)
    if request.method == 'POST':
        f = request.POST['fname']
        l = request.POST['lname']
        e = request.POST['email']
        con = request.POST['contact']
        add = request.POST['add']
        try:
            im = request.FILES['image']
            sign.image = im
            sign.save()
        except:
            pass
        to1 = datetime.date.today()
        sign.user.first_name = f
        sign.user.last_name = l
        sign.user.email = e
        sign.contact = con
        if error != "pat":
            cat = request.POST['type']
            sign.category = cat
            sign.save()
        sign.address = add
        sign.user.save()
        sign.save()
        terror = "create"
    d = {'error':error,'terror':terror,'doc':sign}
    return render(request,'edit_profile.html',d)

@login_required(login_url='login')
def sent_feedback(request):
    terror = None
    if request.method == "POST":
        username = request.POST['uname']
        message = request.POST['msg']
        username = User.objects.get(username=username)
        Feedback.objects.create(user=username, messages=message)
        terror = "create"
    return render(request, 'sent_feedback.html',{'terror':terror})


@login_required(login_url="login")
def train_models_view(request):
    try:
        best_models, evaluation_results, best_model_name, best_model_metrics = train()
        message = "Training completed successfully!"
    except Exception as e:
        message = f"Error during training: {str(e)}"
        evaluation_results = {}
        best_model_name = None
        best_model_metrics = None

    return render(request, 'train_models.html', {
        'message': message,
        'evaluation_results': evaluation_results,
        'best_model_name': best_model_name,
        'best_model_metrics': best_model_metrics,
    })

@login_required(login_url="login")
@login_required(login_url="login")
def predict_disease_view(request):
    if request.method == "POST":
        try:
            # Extract user input from the form
            input_data = {
                'age': request.POST.get('age'),
                'sex': request.POST.get('sex'),
                'cp': request.POST.get('cp'),
                'trestbps': request.POST.get('trestbps'),
                'chol': request.POST.get('chol'),
                'fbs': request.POST.get('fbs'),
                'restecg': request.POST.get('restecg'),
                'thalach': request.POST.get('thalach'),
                'exang': request.POST.get('exang'),
                'oldpeak': request.POST.get('oldpeak'),
                'slope': request.POST.get('slope'),
                'ca': request.POST.get('ca'),
                'thal': request.POST.get('thal'),
            }

            # Preprocess input data
            preprocessed_data = preprocess_inputs(input_data)

            # Make a prediction
            prediction = predict_desease(preprocessed_data)
            result = "Healthy" if prediction == 0 else "Unhealthy"

            # Train and evaluate models (automatically)
            evaluation_results = train

            # Store the prediction result and evaluation results in the session
            request.session['prediction_result'] = result
            request.session['evaluation_results'] = evaluation_results

            # Redirect to the results page
            return redirect('view_results')

        except Exception as e:
            return render(request, 'predict_result.html', {'error': str(e)})

    return render(request, 'predict_form.html')
@login_required(login_url="login")
def view_results(request):
    # Fetch evaluation results
    best_models, evaluation_results, best_model_name = train()

    # Debug: Print evaluation results
    print("Evaluation Results:", evaluation_results)
    # Extract confusion matrix paths for all models
    confusion_matrix_paths = [
        evaluation_results[model]['confusion_matrix_path'] for model in evaluation_results.keys()
    ]

    return render(request, 'evaluation_results.html', {
        'evaluation_results': evaluation_results,
        'best_model_name': best_model_name,
        'confusion_matrix_paths': confusion_matrix_paths,


    })