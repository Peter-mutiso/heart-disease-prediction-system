import logging
import os


def preprocess_inputs(df, scaler):

    # Define constants
    LOG_DIR = "models"
    LOG_FILE = os.path.join(LOG_DIR, "preprocessing.log")
    DATA_FILE = "Machine_Learning/heart.csv"  # Change this path if needed
    PROCESSED_FILE = "models/preprocessed.csv"  # File to save preprocessed data

    FEATURES = ['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg',
                'thalach', 'exang', 'oldpeak', 'slope', 'ca', 'thal', 'target']  # Includes 'target'

    # Ensure log directory exists
    os.makedirs(LOG_DIR, exist_ok=True)

    # Configure logging
    logging.basicConfig(
        filename=LOG_FILE,
        level=logging.DEBUG,
        format="%(asctime)s - %(levelname)s - %(message)s",
    )

    logging.info("✅ Logging initialized successfully!")
