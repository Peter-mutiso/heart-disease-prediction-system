import joblib
import numpy as np

# Load the trained model and preprocessing objects
def load_models(model_path="model.pkl", scaler_path="scaler.pkl"):
    """
    Load the trained model and scaler from disk.
    """
    try:
        model = joblib.load(model_path)
        scaler = joblib.load(scaler_path)
        return model, scaler
    except Exception as e:
        print(f"Error loading models: {e}")
        return None, None

# Preprocess new input data
def preprocess_input(data, scaler):
    """
    Preprocess the input data using the saved scaler.
    """
    try:
        # Convert input data to numpy array and reshape
        data = np.array(data).reshape(1, -1)
        # Scale the data
        data_scaled = scaler.transform(data)
        return data_scaled
    except Exception as e:
        print(f"Error preprocessing input data: {e}")
        return None

# Make predictions
def predict(model, scaler, input_data):
    """
    Make predictions using the trained model.
    """
    try:
        # Preprocess the input data
        input_data_scaled = preprocess_input(input_data, scaler)
        if input_data_scaled is None:
            raise ValueError("Invalid input data.")

        # Make prediction
        prediction = model.predict(input_data_scaled)
        confidence = model.predict_proba(input_data_scaled)[0][1] * 100  # Confidence score
        return prediction, confidence
    except Exception as e:
        print(f"Error making prediction: {e}")
        return None, None