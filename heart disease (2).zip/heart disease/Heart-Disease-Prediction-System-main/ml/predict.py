# models/predict.py
import pickle
import numpy as np

def load_models():
    """ Load trained model and scaler. """
    try:
        with open("models/model.pkl", "rb") as f:
            model = pickle.load(f)
        with open("models/scaler.pkl", "rb") as f:
            scaler = pickle.load(f)
        return model, scaler
    except FileNotFoundError:
        return None, None

def predict_disease(list_data):
    """ Predict heart disease using the pre-trained model. """
    model, scaler = load_models()
    if model is None or scaler is None:
        return "Error: Model or scaler not found"

    # Scale input data
    input_data_scaled = scaler.transform(list_data)

    # Make prediction
    pred = model.predict(input_data_scaled)[0]  # Only return prediction

    return int(pred)
