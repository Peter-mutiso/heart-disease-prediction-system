import os
import pickle
import logging
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, mean_squared_error

# Directories
LOG_DIR = "models"
MODEL_DIR = "models/models"

# Ensure directories exist
os.makedirs(LOG_DIR, exist_ok=True)
os.makedirs(MODEL_DIR, exist_ok=True)

LOG_FILE = os.path.join(LOG_DIR, "training.log")

# Configure logging
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
)

DATA_FILE = "models/preprocessed.csv"

def load_data():
    """Load preprocessed data for training."""
    try:
        if not os.path.exists(DATA_FILE):
            logging.error("❌ Processed data file not found!")
            raise FileNotFoundError("Processed data file missing!")

        df = pd.read_csv(DATA_FILE)
        logging.info("✅ Data loaded successfully.")
        return df
    except Exception as e:
        logging.error(f"❌ Error loading data: {str(e)}")
        raise

def train():
    """Train multiple models with hyperparameter tuning and save the best."""
    try:
        df = load_data()

        # Features and target
        feature_names = ['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg',
                         'thalach', 'exang', 'oldpeak', 'slope', 'ca', 'thal']
        target = 'target'

        if target not in df.columns:
            logging.error("❌ Target column 'target' not found in dataset!")
            raise KeyError("Target column missing!")

        X = df[feature_names]
        y = df[target]

        # Split dataset
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        logging.info(f"✅ Data split: {X_train.shape[0]} training samples, {X_test.shape[0]} test samples.")

        # Scale features
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)

        # Save scaler
        scaler_path = os.path.join(MODEL_DIR, "scaler.pkl")
        pickle.dump(scaler, open(scaler_path, "wb"))
        logging.info(f"✅ Scaler saved at {scaler_path}")

        # Models and hyperparameters
        models = {
            'RandomForest': RandomForestClassifier(random_state=42),
            'GradientBoosting': GradientBoostingClassifier(random_state=42),
            'SVM': SVC(probability=True, random_state=42)
        }

        param_grids = {
            'RandomForest': {'n_estimators': [100, 200], 'max_depth': [None, 10, 20], 'min_samples_split': [2, 5]},
            'GradientBoosting': {'n_estimators': [100, 200], 'learning_rate': [0.01, 0.1], 'max_depth': [3, 5]},
            'SVM': {'C': [0.1, 1, 10], 'kernel': ['linear', 'rbf']}
        }

        best_models = {}
        best_scores = {}

        # Training each model
        for model_name, model in models.items():
            print(f"\n🔄 Training {model_name} with hyperparameter tuning...")
            logging.info(f"🔄 Training {model_name}...")

            grid_search = GridSearchCV(model, param_grids[model_name], cv=5, scoring='accuracy')
            grid_search.fit(X_train_scaled, y_train)

            best_model = grid_search.best_estimator_
            best_models[model_name] = best_model

            # Evaluate
            y_pred = best_model.predict(X_test_scaled)
            accuracy = accuracy_score(y_test, y_pred)
            precision = precision_score(y_test, y_pred, average='weighted')
            recall = recall_score(y_test, y_pred, average='weighted')
            f1 = f1_score(y_test, y_pred, average='weighted')
            mse = mean_squared_error(y_test, y_pred)

            print(f"✅ {model_name} - Accuracy: {accuracy:.4f}, Precision: {precision:.4f}, Recall: {recall:.4f}, F1: {f1:.4f}, MSE: {mse:.4f}")
            logging.info(f"✅ {model_name} - Accuracy: {accuracy:.4f}, Precision: {precision:.4f}, Recall: {recall:.4f}, F1: {f1:.4f}, MSE: {mse:.4f}")

            # Save model
            model_path = os.path.join(MODEL_DIR, f"{model_name}.pkl")
            joblib.dump(best_model, model_path)
            logging.info(f"✅ {model_name} saved at {model_path}")
            print(f"📁 Model saved at {model_path}")

            best_scores[model_name] = accuracy  # Store accuracy score

        # Select the best model based on accuracy
        best_model_name = max(best_scores, key=best_scores.get)
        print(f"\n🏆 Best model: {best_model_name} with Accuracy: {best_scores[best_model_name]:.4f}")
        logging.info(f"🏆 Best model: {best_model_name} with Accuracy: {best_scores[best_model_name]:.4f}")

        return best_models, best_model_name

    except Exception as e:
        logging.error(f"❌ Training error: {str(e)}")
        print(f"Error: {str(e)}")

if __name__ == "__main__":
    train()
