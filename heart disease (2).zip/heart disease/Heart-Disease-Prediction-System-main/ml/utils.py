import os
import logging
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, mean_squared_error

# Define constants
LOG_DIR = "models"
MODEL_DIR = os.path.join(LOG_DIR, "models/models")
DATA_FILE = os.path.join(LOG_DIR, "models/preprocessed.csv")
LOG_FILE = os.path.join(LOG_DIR, "models/training.log")

# Ensure directories exist
os.makedirs(LOG_DIR, exist_ok=True)
os.makedirs(MODEL_DIR, exist_ok=True)

# Configure logging
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
)

logging.info("✅ Logging initialized successfully!")

# Features and target
FEATURES = ['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg',
            'thalach', 'exang', 'oldpeak', 'slope', 'ca', 'thal', 'target']


def load_data(filepath=DATA_FILE):
    """
    Load dataset from CSV and return features (X) and target (y).
    Logs errors if data loading fails.
    """
    try:
        logging.info(f"📥 Loading data from {filepath}...")

        if not os.path.exists(filepath):
            logging.error(f"❌ File not found: {filepath}")
            return None, None  # Return None if the file is missing

        df = pd.read_csv(filepath)

        # Ensure dataset has all required features
        missing_cols = [col for col in FEATURES if col not in df.columns]
        if missing_cols:
            logging.error(f"❌ Missing columns in dataset: {missing_cols}")
            return None, None

        logging.info(f"✅ Data Loaded Successfully. Shape: {df.shape}")

        X = df.drop(columns=["target"])  # Features
        y = df["target"]  # Labels

        return X, y
    except pd.errors.EmptyDataError:
        logging.error("❌ Error: The dataset is empty.")
        return None, None
    except Exception as e:
        logging.error(f"❌ Unexpected error while loading data: {e}")
        return None, None


def save_preprocessed_data(X, y, filepath=DATA_FILE):
    """
    Saves the preprocessed data to a CSV file.
    """
    try:
        if X is None or y is None:
            logging.error("❌ No data to save. Preprocessing failed.")
            return False

        # Merge X and y into a single DataFrame
        df = pd.concat([X, y], axis=1)
        df.to_csv(filepath, index=False)

        logging.info(f"✅ Preprocessed data saved to {filepath}")
        return True
    except Exception as e:
        logging.error(f"❌ Error saving preprocessed data: {e}")
        return False


def preprocess_input(data_dict):
    """
    Convert user input dictionary into a numerical NumPy array for model prediction.
    Logs any conversion errors.
    """
    try:
        list_data = []
        for key in FEATURES[:-1]:  # Exclude "target"
            value = data_dict.get(key, 0)  # Default to 0 if missing
            if key == "sex":
                list_data.append(0 if str(value).lower() in ["male", "m"] else 1)
            else:
                list_data.append(float(value))

        logging.info(f"✅ Preprocessed input: {list_data}")
        return np.array(list_data).reshape(1, -1)

    except ValueError as ve:
        logging.error(f"❌ ValueError in input preprocessing: {ve}")
        return None
    except Exception as e:
        logging.error(f"❌ Unexpected error in input preprocessing: {e}")
        return None


def train_models():
    """Train multiple models with hyperparameter tuning and save the best."""
    try:
        df = load_data()

        # Features and target
        feature_names = FEATURES[:-1]  # Exclude "target"
        target = 'target'

        if target not in df.columns:
            logging.error("❌ Target column 'target' not found in dataset!")
            raise KeyError("Target column missing!")

        X = df[feature_names]
        y = df[target]

        # Split dataset
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        logging.info(f"✅ Data split: {X_train.shape[0]} training samples, {X_test.shape[0]} test samples.")

        # Scale features
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)

        # Save scaler
        scaler_path = os.path.join(MODEL_DIR, "scaler.pkl")
        joblib.dump(scaler, scaler_path)
        logging.info(f"✅ Scaler saved at {scaler_path}")

        # Models and hyperparameters
        models = {
            'RandomForest': RandomForestClassifier(random_state=42),
            'GradientBoosting': GradientBoostingClassifier(random_state=42),
            'SVM': SVC(probability=True, random_state=42)
        }

        param_grids = {
            'RandomForest': {'n_estimators': [100, 200], 'max_depth': [None, 10, 20], 'min_samples_split': [2, 5]},
            'GradientBoosting': {'n_estimators': [100, 200], 'learning_rate': [0.01, 0.1], 'max_depth': [3, 5]},
            'SVM': {'C': [0.1, 1, 10], 'kernel': ['linear', 'rbf']}
        }

        best_models = {}
        evaluation_results = {}

        # Training each model
        for model_name, model in models.items():
            logging.info(f"🔄 Training {model_name}...")
            grid_search = GridSearchCV(model, param_grids[model_name], cv=5, scoring='accuracy')
            grid_search.fit(X_train_scaled, y_train)

            best_model = grid_search.best_estimator_
            best_models[model_name] = best_model

            # Evaluate
            y_pred = best_model.predict(X_test_scaled)
            evaluation_results[model_name] = {
                "accuracy": accuracy_score(y_test, y_pred),
                "precision": precision_score(y_test, y_pred, average='weighted'),
                "recall": recall_score(y_test, y_pred, average='weighted'),
                "f1": f1_score(y_test, y_pred, average='weighted'),
            }

            # Save model
            model_path = os.path.join(MODEL_DIR, f"{model_name}.pkl")
            joblib.dump(best_model, model_path)
            logging.info(f"✅ {model_name} saved at {model_path}")

        # Determine the best model based on accuracy
        best_model_name = max(evaluation_results, key=lambda k: evaluation_results[k]['accuracy'])
        best_model_metrics = evaluation_results[best_model_name]

        logging.info(f"🏆 Best model: {best_model_name} with Accuracy: {best_model_metrics['accuracy']:.4f}")

        return best_models, evaluation_results, best_model_name, best_model_metrics

    except Exception as e:
        logging.error(f"❌ Training error: {str(e)}")
        raise


def load_best_model():
    """
    Load the best model and scaler for prediction.
    """
    try:
        # Load scaler
        scaler_path = os.path.join(MODEL_DIR, "scaler.pkl")
        scaler = joblib.load(scaler_path)

        # Load best model (e.g., RandomForest)
        best_model_name = "SVM"  # Replace with logic to dynamically load the best model
        model_path = os.path.join(MODEL_DIR, f"{best_model_name}.pkl")
        model = joblib.load(model_path)

        return model, scaler
    except Exception as e:
        logging.error(f"❌ Error loading model or scaler: {str(e)}")
        return None, None


def predict_disease(input_data):
    """
    Predict heart disease using the best model.
    """
    try:
        # Load the best model and scaler
        model, scaler = load_best_model()
        if model is None or scaler is None:
            return "Error: Model or scaler not found"

        # Scale input data
        input_data_scaled = scaler.transform(input_data)

        # Make prediction
        prediction = model.predict(input_data_scaled)
        return int(prediction[0])  # Return the prediction (0 or 1)

    except Exception as e:
        logging.error(f"❌ Prediction error: {str(e)}")
        return "Error: Prediction failed"


