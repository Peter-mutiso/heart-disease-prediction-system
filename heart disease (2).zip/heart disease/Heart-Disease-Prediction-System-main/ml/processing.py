import numpy as np
import pandas as pd
import logging
import os

# Define constants
LOG_DIR = "models"
LOG_FILE = os.path.join(LOG_DIR, "preprocessing.log")
DATA_FILE = "heart.csv"  # Change this path if needed
PROCESSED_FILE = "models/preprocessed.csv"  # File to save preprocessed data

FEATURES = ['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg',
            'thalach', 'exang', 'oldpeak', 'slope', 'ca', 'thal', 'target']  # Includes 'target'

# Ensure log directory exists
os.makedirs(LOG_DIR, exist_ok=True)

# Configure logging
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
)

logging.info("✅ Logging initialized successfully!")


def load_data(filepath=DATA_FILE):
    """
    Load dataset from CSV and return features (X) and target (y).
    Logs errors if data loading fails.
    """
    try:
        logging.info(f"📥 Loading data from {filepath}...")

        if not os.path.exists(filepath):
            logging.error(f"❌ File not found: {filepath}")
            return None, None  # Return None if the file is missing

        df = pd.read_csv(filepath)

        # Ensure dataset has all required features
        missing_cols = [col for col in FEATURES if col not in df.columns]
        if missing_cols:
            logging.error(f"❌ Missing columns in dataset: {missing_cols}")
            return None, None

        logging.info(f"✅ Data Loaded Successfully. Shape: {df.shape}")

        X = df.drop(columns=["target"])  # Features
        y = df["target"]  # Labels

        return X, y
    except pd.errors.EmptyDataError:
        logging.error("❌ Error: The dataset is empty.")
        return None, None
    except Exception as e:
        logging.error(f"❌ Unexpected error while loading data: {e}")
        return None, None


def save_preprocessed_data(X, y, filepath=PROCESSED_FILE):
    """
    Saves the preprocessed data to a CSV file.
    """
    try:
        if X is None or y is None:
            logging.error("❌ No data to save. Preprocessing failed.")
            return False

        # Merge X and y into a single DataFrame
        df = pd.concat([X, y], axis=1)
        df.to_csv(filepath, index=False)

        logging.info(f"✅ Preprocessed data saved to {filepath}")
        return True
    except Exception as e:
        logging.error(f"❌ Error saving preprocessed data: {e}")
        return False


def preprocess_input(data_dict):
    """
    Convert user input dictionary into a numerical NumPy array for model prediction.
    Logs any conversion errors.
    """
    try:
        list_data = []
        for key in FEATURES[:-1]:  # Exclude "target"
            value = data_dict.get(key, 0)  # Default to 0 if missing
            if key == "sex":
                list_data.append(0 if str(value).lower() in ["male", "m"] else 1)
            else:
                list_data.append(float(value))

        logging.info(f"✅ Preprocessed input: {list_data}")
        return np.array(list_data).reshape(1, -1)

    except ValueError as ve:
        logging.error(f"❌ ValueError in input preprocessing: {ve}")
        return None
    except Exception as e:
        logging.error(f"❌ Unexpected error in input preprocessing: {e}")
        return None


if __name__ == "__main__":
    # Load and preprocess data
    X, y = load_data()

    if X is not None and y is not None:
        logging.info("🚀 Data successfully loaded and ready for preprocessing!")
        print("🚀 Data successfully loaded and ready for preprocessing!")

        # Save preprocessed data
        if save_preprocessed_data(X, y):
            print(f"✅ Preprocessed data saved to {PROCESSED_FILE}")
        else:
            print("❌ Failed to save preprocessed data.")
    else:
        logging.error("❌ Data loading failed! Check logs for more details.")
        print("❌ Data loading failed! Check logs for more details.")
