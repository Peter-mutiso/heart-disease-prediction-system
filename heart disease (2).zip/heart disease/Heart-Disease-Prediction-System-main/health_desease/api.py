from rest_framework import routers
# from  import api_views as myapp_views
#
# router = routers.DefaultRouter()
# router.register(r'sensovizpromotion', myapp_views.SensovizPromotiontViewset)
# router.register(r'sensovizmodel', myapp_views.SensovizModelViewset)
# router.register(r'sensovizapp', myapp_views.SensovizAppViewset)
# router.register(r'sensoviznotify', myapp_views.SensovizNotifyViewset)
# router.register(r'collectorcategory', myapp_views.CollectorCategoryViewset)
# router.register(r'collectorgrading', myapp_views.CollectorGradingViewset)
